update
======

|Build Status| |PyPI version|

**update** is a


Install
-------

::

    $ pip install update


Usage
-----

.. code:: py

    import update

    update.check()


.. |Build Status| image:: https://travis-ci.org/lmittmann/update.svg?branch=master
    :target: https://travis-ci.org/lmittmann/update
.. |PyPI version| image:: https://img.shields.io/pypi/v/update.svg
    :target: https://pypi.org/project/update


