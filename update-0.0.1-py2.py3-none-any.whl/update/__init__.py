from update.check import check


__version__ = '0.0.1'
